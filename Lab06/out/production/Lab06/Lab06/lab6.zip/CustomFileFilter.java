package Lab06;


import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class CustomFileFilter implements FilenameFilter {
    private List<String> acceptedExtensions;
    private List<String> acceptedWords;

    public CustomFileFilter() {
        this.acceptedExtensions = readExtensionsFromFile("extension.in");
        this.acceptedWords = readWordsFromFile("words.in");
    }

    private List<String> readExtensionsFromFile(String filename) {
        List<String> extensions = new ArrayList<>();
        try (RandomAccessFile file = new RandomAccessFile(filename, "r")) {
            String line;
            while ((line = file.readLine()) != null) {
                extensions.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return extensions;
    }

    private List<String> readWordsFromFile(String filename) {
        List<String> words = new ArrayList<>();
        try (RandomAccessFile file = new RandomAccessFile(filename, "r")) {
            String line;
            while ((line = file.readLine()) != null) {
                words.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return words;
    }

    @Override
    public boolean accept(File dir, String name) {
        File file = new File(dir, name);
        if (file.isFile()) {
            for (String extension : acceptedExtensions) {
                if (name.toLowerCase().endsWith("." + extension.toLowerCase())) {
                    for (String word : acceptedWords) {
                        if (name.toLowerCase().contains(word.toLowerCase())) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static void main(String[] args) {

        File directory = new File("/mnt/c/Users/gie10/OneDrive - Universitatea Politehnica Bucuresti/An 2/Semestru 1/POO/Lab06/Lab06");
        this.acceptedExtensions = readExtensionsFromFile("director/fisiere_java/extension.in");
        this.acceptedWords = readWordsFromFile("director/fisiere_java/words.in");

        CustomFileFilter fileFilter = new CustomFileFilter();
        File[] matchingFiles = directory.listFiles(fileFilter);

        if (matchingFiles != null) {
            for (File file : matchingFiles) {
                System.out.println(file.getName());
            }
        }
    }
}

