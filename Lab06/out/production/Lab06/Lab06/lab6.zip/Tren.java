package Lab06;

import java.util.ArrayList;
import java.util.List;

abstract class Vagon {
    private int capacitatePasageri;
    private int capacitateColete;

    public Vagon(int capacitatePasageri, int capacitateColete) {
        this.capacitatePasageri = capacitatePasageri;
        this.capacitateColete = capacitateColete;
    }

    public void deschideUsi() {
        System.out.println("Ușile sunt deschise.");
    }

    public void inchideUsi() {
        System.out.println("Ușile sunt închise.");
    }

    public void blocheazaGeamuri() {
        System.out.println("Geamurile sunt blocate.");
    }

    public int getCapacitatePasageri() {
        return capacitatePasageri;
    }

    public int getCapacitateColete() {
        return capacitateColete;
    }

    public abstract String getTipVagon();
}

class CalatoriA extends Vagon {
    public CalatoriA() {
        super(40, 300);
    }

    @Override
    public String getTipVagon() {
        return "Vagon de tip CalatoriA";
    }
}

class CalatoriB extends Vagon {
    public CalatoriB() {
        super(50, 400);
    }

    @Override
    public String getTipVagon() {
        return "Vagon de tip CalatoriB";
    }

    @Override
    public void blocheazaGeamuri() {
        System.out.println("Geamurile sunt blocate.");
    }
}

class Marfa extends Vagon {
    public Marfa() {
        super(0, 400);
    }

    @Override
    public String getTipVagon() {
        return "Vagon de tip Marfa";
    }

    @Override
    public void deschideUsi() {
        System.out.println("Deschiderea ușilor se face manual.");
    }

    @Override
    public void inchideUsi() {
        System.out.println("Închiderea ușilor se face manual.");
    }
}

public class Tren implements Comparable<Tren> {
    private List<Vagon> vagoane = new ArrayList<>();

    public void addVagon(Vagon vagon) {
        vagoane.add(vagon);
    }

    public int numarTotalColete() {
        int totalColete = 0;
        for (Vagon vagon : vagoane) {
            totalColete += vagon.getCapacitateColete();
        }
        return totalColete;
    }

    @Override
    public int compareTo(Tren otherTren) {
        return Integer.compare(this.numarTotalColete(), otherTren.numarTotalColete());
    }

    public void afiseazaTipurileVagoanelor() {
        for (Vagon vagon : vagoane) {
            System.out.println(vagon.getTipVagon());
        }
    }

    @Override
    public String toString() {
        return "Trenul are " + numarTotalColete() + " colete și conține următoarele tipuri de vagoane:\n";
    }

}
