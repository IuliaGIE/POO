package lab11;
public interface Element {
    void accept(Visitor visitor);
}
