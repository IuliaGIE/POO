public class Main {
    public static void main(String[] args) {

        Numar n = new Numar(7);
        System.out.println("Suma de 1 numar: " + n.suma(3));
        System.out.println("Suma de 2 numere: " + n.suma(3, 4));
        System.out.println("Suma de 3 numere: " + n.suma(3, 4, 5));
        System.out.println("Suma de 4 numere: " + n.suma(3, 4, 5, 6));

    }
}