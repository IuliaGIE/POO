public class ex4 {
    public static void main(String[] args){
        int i;
        for(i = 0; i < args.length; i ++){ // for(String arg : args)
            System.out.printf(args[i]);
        }

    }
}
