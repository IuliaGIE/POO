public class print {
    void print(String a) {
        System.out.println(a);
    }
}
