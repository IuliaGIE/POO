
class Problema2 {
    public static void main(String args[]) {
        Problema2 obiect = new Problema2(); // creare obiect de tip Problema2
        obiect.print("cuvinte"); //apelare metoda print
    }
    void print(String a) {
        System.out.println(a);
    }
}