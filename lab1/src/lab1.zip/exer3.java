

 public class exer3 {
    public static void main(String args[]) {
        print obiect = new print(); // creare obiect de tip Problema2
        obiect.print("cuvinte"); //apelare metoda print
    }
}