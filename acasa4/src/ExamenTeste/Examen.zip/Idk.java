package ExamenTeste;
class Twisty {
    static int index = 1;
    public static void main(String[] args) {
        new Twisty().go();
    }
    void go() {
        int[][] dd = {{9,8,7}, {6,5,4}, {3,2,1,0}};
        System.out.println(dd[index++][index++]);
    }
}
