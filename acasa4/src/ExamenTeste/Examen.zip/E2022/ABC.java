package ExamenTeste.E2022;

class A {
    public A(int x) {
        this(x + 0.0);
        System.out.println("A1 " + x);
    }

    public A(double x) {

        System.out.println("A2 " + x);
    }
}
class B extends A {
    public B(int x) {
        super(++x);
        System.out.println("B1 " + x);
    }
    public B(double x) {
        super(x++);
        System.out.println("B2 " + x);
    }
}
class C extends B {
    public C() {
        //super(7);
        super (7.0);
    }
}

    public class ABC {

        public static void main(String args[]) {

            C obj = new C();
        }
    }

