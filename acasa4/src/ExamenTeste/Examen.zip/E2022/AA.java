package ExamenTeste.E2022;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

class AA { }
class BB extends AA{ }
class Testa{
    //List<AA> method () {return new ArrayList<BB>();}
    //List<BB> method () {return new ArrayList<BB>();}
    //ArrayList<AA> method () {return new ArrayList<BB>();}
    //Iterable<? extends AA> method () {return new ArrayList<BB>();}
    //Collection<?> method () {return new ArrayList<BB>();}
}
