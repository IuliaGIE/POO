package lab7;
import java.util.*;

public class Ex5 {
}
