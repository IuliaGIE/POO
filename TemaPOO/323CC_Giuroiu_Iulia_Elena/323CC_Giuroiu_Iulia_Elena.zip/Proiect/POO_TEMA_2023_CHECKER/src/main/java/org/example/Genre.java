package org.example;
public enum Genre {

    Action,
    Adventure,
    Comedy,
    Drama,
    Horror,
    SF,
    Fantasy,
    Romance,
    Mystery,
    Thriller,
    Crime,
    Biography,
    History,
    War,
    Cooking
}
