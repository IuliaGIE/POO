package org.example;

public enum AccountType {

    Regular,
    Contributor,
    Admin

}