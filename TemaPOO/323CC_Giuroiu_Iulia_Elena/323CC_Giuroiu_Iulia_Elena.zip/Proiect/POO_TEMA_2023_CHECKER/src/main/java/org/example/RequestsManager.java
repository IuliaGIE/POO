package org.example;

public interface RequestsManager {
    void createRequest(Request r);
    void removeRequest(Request r);
}
