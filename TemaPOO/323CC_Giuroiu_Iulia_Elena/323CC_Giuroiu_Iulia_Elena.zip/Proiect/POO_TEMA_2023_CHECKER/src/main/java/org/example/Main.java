package org.example;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        IMDB imdbApp = new IMDB();
        imdbApp.run();
    }
}
