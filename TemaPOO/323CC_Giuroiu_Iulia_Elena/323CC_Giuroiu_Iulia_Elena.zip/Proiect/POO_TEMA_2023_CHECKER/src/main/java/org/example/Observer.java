package org.example;

public interface Observer {
    public void update(String message);
}
