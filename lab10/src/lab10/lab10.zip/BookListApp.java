package lab10;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class BookListApp extends JFrame {
    public BookListApp() {
        super("Book List");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a Vector to hold Book objects
        Vector<Book> books = new Vector<>();
        books.add(new Book("The Great Gatsby", "F. Scott Fitzgerald", ""));
        books.add(new Book("To Kill a Mockingbird", "Harper Lee", ""));
        books.add(new Book("1984", "George Orwell", ""));
        books.add(new Book("Pride and Prejudice", "Jane Austen", ""));

        // Add more books for testing scrolling
        for (int i = 0; i < 20; i++) {
            books.add(new Book("Book" + (i + 1), "Author" + (i + 1), ""));
        }

        // Create a JList with the Vector of Book objects
        JList<Book> bookList = new JList<>(books);

        // Set the cell renderer to display title and author
        bookList.setCellRenderer(new BookListCellRenderer());

        // Make the list scrollable
        JScrollPane scrollPane = new JScrollPane(bookList);

        // Set layout and add components
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BookListApp2::new);
    }
}

class BookListCellRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        if (value instanceof Book) {
            Book book = (Book) value;
            setText(book.getName() + " by " + book.getAuthor());
        } else {
            setText("");
        }

        return this;
    }
}

