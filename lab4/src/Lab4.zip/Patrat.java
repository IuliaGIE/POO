public class Patrat extends Dreptunghi{

    public Patrat(int latura) {
        super(latura, latura);
    }

}
