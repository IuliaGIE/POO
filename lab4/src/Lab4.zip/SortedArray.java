public class SortedArray extends Array{
    public void addElement(Integer x) {
        super.addElement(x);
        sort();
    }
}
